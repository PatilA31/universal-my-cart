import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

const initialItems = [
  {
    id: 1, name: "Sony WH-1000XM5 Wireless Headphones", category: "Electronics",
    image: "🎧", qty: 1,
    sources: [
      { store: "Amazon", price: 29990, oldPrice: 34990, delivery: "Tomorrow", url: "#" },
      { store: "Flipkart", price: 28999, oldPrice: 33990, delivery: "2 days", url: "#" },
      { store: "Myntra", price: 31999, oldPrice: 35990, delivery: "3 days", url: "#" }
    ]
  },
  {
    id: 2, name: "Nike Air Max Running Shoes", category: "Fashion",
    image: "👟", qty: 1,
    sources: [
      { store: "Myntra", price: 7495, oldPrice: 9995, delivery: "2 days", url: "#" },
      { store: "Amazon", price: 7999, oldPrice: 10495, delivery: "Tomorrow", url: "#" },
      { store: "Flipkart", price: 8299, oldPrice: 10999, delivery: "3 days", url: "#" }
    ]
  },
  {
    id: 3, name: "Milton Thermosteel Flask 1L", category: "Home",
    image: "🧴", qty: 2,
    sources: [
      { store: "Flipkart", price: 899, oldPrice: 1299, delivery: "Tomorrow", url: "#" },
      { store: "Amazon", price: 949, oldPrice: 1399, delivery: "2 days", url: "#" },
      { store: "Meesho", price: 1099, oldPrice: 1499, delivery: "4 days", url: "#" }
    ]
  },
  {
    id: 4, name: "Minimalist 10% Niacinamide Face Serum", category: "Beauty",
    image: "🧴", qty: 1,
    sources: [
      { store: "Amazon", price: 599, oldPrice: 699, delivery: "Tomorrow", url: "#" },
      { store: "Meesho", price: 569, oldPrice: 749, delivery: "3 days", url: "#" },
      { store: "Flipkart", price: 625, oldPrice: 699, delivery: "2 days", url: "#" }
    ]
  }
];

const storeMeta = {
  Amazon: { cls: "amazon", letter: "a" },
  Flipkart: { cls: "flipkart", letter: "f" },
  Myntra: { cls: "myntra", letter: "m" },
  Meesho: { cls: "meesho", letter: "s" }
};

const money = n => "₹" + n.toLocaleString("en-IN");

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [tab, setTab] = useState("overview");
  const [items, setItems] = useState(initialItems);
  const [search, setSearch] = useState("");
  const [link, setLink] = useState("");
  const [toast, setToast] = useState("");
  const [loginMode, setLoginMode] = useState("login");

  const filtered = useMemo(
    () => items.filter(x => x.name.toLowerCase().includes(search.toLowerCase())),
    [items, search]
  );

  const totalBest = items.reduce((sum, item) => sum + Math.min(...item.sources.map(s => s.price)) * item.qty, 0);
  const totalAmazon = items.reduce((sum, item) => sum + (item.sources.find(s => s.store === "Amazon")?.price || 0) * item.qty, 0);
  const savings = Math.max(0, totalAmazon - totalBest);

  const notify = msg => {
    setToast(msg);
    setTimeout(() => setToast(""), 2800);
  };

  const addSharedLink = () => {
    if (!link.trim()) return;
    const next = {
      id: Date.now(),
      name: "Product imported from shared link",
      category: "Imported",
      image: "📦", qty: 1,
      sources: [
        { store: "Amazon", price: 1499, oldPrice: 1899, delivery: "Tomorrow", url: link },
        { store: "Flipkart", price: 1549, oldPrice: 1999, delivery: "2 days", url: link }
      ]
    };
    setItems(prev => [next, ...prev]);
    setLink("");
    notify("Product added to Universal My Cart");
  };

  if (!loggedIn) return <Login loginMode={loginMode} setLoginMode={setLoginMode} onLogin={() => setLoggedIn(true)} />;

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">U</div>
          <div><strong>Universal</strong><span>My Cart</span></div>
        </div>

        <nav>
          <button className={tab === "overview" ? "active" : ""} onClick={() => setTab("overview")}>⌂ <span>Overview</span></button>
          <button className={tab === "mycart" ? "active" : ""} onClick={() => setTab("mycart")}>🛒 <span>My Cart</span><b>{items.length}</b></button>
          <button className={tab === "compare" ? "active" : ""} onClick={() => setTab("compare")}>⇄ <span>Compare Prices</span></button>
          <button className={tab === "how" ? "active" : ""} onClick={() => setTab("how")}>? <span>How it works</span></button>
        </nav>

        <div className="sidebar-bottom">
          <div className="sync-card">
            <div className="sync-dot"></div>
            <div><strong>Cart sync active</strong><small>Last synced 2 min ago</small></div>
          </div>
          <button className="profile-mini" onClick={() => setLoggedIn(false)}>
            <div className="avatar">AP</div><div><strong>Amol Patil</strong><small>Sign out</small></div>
          </button>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <div className="eyebrow">UNIVERSAL MY CART</div>
            <h1>{tab === "overview" ? "Good morning, Amol" : tab === "mycart" ? "My Cart" : tab === "compare" ? "Price Comparison" : "How Universal My Cart works"}</h1>
          </div>
          <div className="top-actions">
            <button className="icon-btn">⌕</button>
            <div className="notification">3</div>
            <div className="avatar">AP</div>
          </div>
        </header>

        {tab === "overview" && <Overview items={items} totalBest={totalBest} savings={savings} onGo={setTab} />}
        {tab === "mycart" && <CartView items={filtered} search={search} setSearch={setSearch} onAdd={addSharedLink} link={link} setLink={setLink} notify={notify} />}
        {tab === "compare" && <Compare items={items} notify={notify} />}
        {tab === "how" && <HowItWorks />}

        {toast && <div className="toast">✓ {toast}</div>}
      </main>
    </div>
  );
}

function Login({ loginMode, setLoginMode, onLogin }) {
  return (
    <div className="login-page">
      <div className="login-visual">
        <div className="visual-content">
          <div className="brand large"><div className="brand-mark">U</div><div><strong>Universal</strong><span>My Cart</span></div></div>
          <h2>One cart.<br/><em>Every store.</em></h2>
          <p>Bring Amazon, Flipkart, Myntra, Meesho and more into one simple shopping view.</p>
          <div className="floating-products"><span>🎧</span><span>👟</span><span>⌚</span><span>📱</span></div>
        </div>
      </div>
      <div className="login-panel">
        <div className="login-box">
          <div className="mobile-brand brand"><div className="brand-mark">U</div><div><strong>Universal</strong><span>My Cart</span></div></div>
          <div className="eyebrow">WELCOME BACK</div>
          <h1>{loginMode === "login" ? "Sign in to your cart" : "Create your account"}</h1>
          <p className="muted">{loginMode === "login" ? "See everything you saved across shopping apps." : "Start comparing your carts in one place."}</p>
          <label>Email address</label><input placeholder="you@example.com" defaultValue="amol@example.com" />
          <label>Password</label><input type="password" placeholder="••••••••" defaultValue="password" />
          {loginMode === "login" && <div className="login-row"><label className="check"><input type="checkbox" defaultChecked /> Remember me</label><a>Forgot password?</a></div>}
          <button className="primary wide" onClick={onLogin}>{loginMode === "login" ? "Sign in →" : "Create account →"}</button>
          <div className="divider"><span>or continue with</span></div>
          <button className="google">G <span>Continue with Google</span></button>
          <p className="switch">{loginMode === "login" ? "New to Universal My Cart?" : "Already have an account?"} <button onClick={() => setLoginMode(loginMode === "login" ? "signup" : "login")}>{loginMode === "login" ? "Create account" : "Sign in"}</button></p>
        </div>
      </div>
    </div>
  );
}

function Overview({ items, totalBest, savings, onGo }) {
  return <section>
    <div className="hero-card">
      <div><span className="pill">SMART SHOPPING</span><h2>All your carts.<br/><span>One place.</span></h2><p>Track products from your favourite stores and instantly spot the best price before you buy.</p><button className="primary" onClick={() => onGo("mycart")}>View my cart →</button></div>
      <div className="hero-art"><div className="orbit"></div><div className="cart-icon">🛒</div><div className="mini-card one">Amazon <strong>₹29,990</strong></div><div className="mini-card two">Flipkart <strong>₹28,999</strong></div><div className="mini-card three">Myntra <strong>₹31,999</strong></div></div>
    </div>

    <div className="stats">
      <Stat label="Items across carts" value={items.length} sub="4 stores connected" icon="🛒" />
      <Stat label="Best cart value" value={money(totalBest)} sub="Lowest available prices" icon="↘" />
      <Stat label="Potential savings" value={money(savings)} sub="vs. buying from Amazon" icon="₹" />
      <Stat label="Price checks" value="12" sub="Updated today" icon="↻" />
    </div>

    <div className="section-heading"><div><h3>Recently added</h3><p>Products waiting in your universal cart</p></div><button className="text-btn" onClick={() => onGo("mycart")}>View all →</button></div>
    <div className="product-grid">{items.slice(0,3).map(item => <ProductCard key={item.id} item={item} />)}</div>
  </section>;
}

function Stat({label,value,sub,icon}) {
  return <div className="stat"><div className="stat-icon">{icon}</div><div><small>{label}</small><strong>{value}</strong><span>{sub}</span></div></div>;
}

function ProductCard({item}) {
  const best = [...item.sources].sort((a,b)=>a.price-b.price)[0];
  return <div className="product-card">
    <div className="product-image">{item.image}</div>
    <div className="product-info"><span className="category">{item.category}</span><h4>{item.name}</h4><div className="best-line"><span>Best price</span><strong>{money(best.price)}</strong></div><div className="store-row"><Store store={best.store} /> <span>• {best.delivery}</span><button className="tiny">Buy ↗</button></div></div>
  </div>;
}

function Store({store}) {
  const m = storeMeta[store] || {cls:"other",letter:"•"};
  return <span className={`store ${m.cls}`}><i>{m.letter}</i>{store}</span>;
}

function CartView({items,search,setSearch,onAdd,link,setLink,notify}) {
  return <section>
    <div className="import-card">
      <div className="import-icon">↗</div><div className="import-copy"><h3>Add anything to Universal My Cart</h3><p>Paste a product link from Amazon, Flipkart, Myntra, Meesho or any supported store.</p></div>
      <div className="import-input"><input value={link} onChange={e=>setLink(e.target.value)} placeholder="Paste product URL here..." /><button className="primary" onClick={onAdd}>Add item</button></div>
    </div>
    <div className="section-heading cart-heading"><div><h3>{items.length} products</h3><p>Sorted by recently added</p></div><input className="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search your cart..." /></div>
    <div className="cart-list">{items.map(item => <CartRow key={item.id} item={item} notify={notify} />)}</div>
  </section>;
}

function CartRow({item,notify}) {
  const best = [...item.sources].sort((a,b)=>a.price-b.price)[0];
  const highest = Math.max(...item.sources.map(s=>s.price));
  return <div className="cart-row">
    <div className="row-product"><div className="row-image">{item.image}</div><div><span className="category">{item.category}</span><h4>{item.name}</h4><small>Qty: {item.qty}</small></div></div>
    <div className="price-summary"><small>BEST PRICE</small><strong>{money(best.price)}</strong><span>Save up to {money(highest-best.price)}</span></div>
    <div className="price-sources">{item.sources.map(s=><div className={`source ${s.store===best.store ? "winner":""}`} key={s.store}><Store store={s.store}/><strong>{money(s.price)}</strong>{s.store===best.store && <b>BEST</b>}</div>)}</div>
    <button className="buy-btn" onClick={()=>notify(`Opening ${best.store} for ${item.name}`)}>Buy ↗</button>
  </div>;
}

function Compare({items,notify}) {
  return <section>
    <div className="compare-intro"><div><span className="pill">PRICE INTELLIGENCE</span><h2>Know the best price<br/>before you buy.</h2><p>We compare the same product across connected stores so you don't have to open five apps.</p></div><div className="compare-save">Average savings<br/><strong>₹1,847</strong><small>per shopping session</small></div></div>
    <div className="compare-table"><div className="table-head"><span>PRODUCT</span><span>AMAZON</span><span>FLIPKART</span><span>MYNTRA</span><span>MEESHO</span><span>BEST</span></div>
      {items.map(item => <div className="table-row" key={item.id}><div className="table-product"><span>{item.image}</span><div><strong>{item.name}</strong><small>{item.category}</small></div></div>{["Amazon","Flipkart","Myntra","Meesho"].map(store=>{const s=item.sources.find(x=>x.store===store); return <div key={store} className="table-price">{s ? money(s.price) : "—"}</div>})}<div><button className="best-btn" onClick={()=>notify(`Best price is on ${[...item.sources].sort((a,b)=>a.price-b.price)[0].store}`)}>{[...item.sources].sort((a,b)=>a.price-b.price)[0].store} ↗</button></div></div>)}
    </div>
  </section>;
}

function HowItWorks() {
  return <section className="how">
    <div className="how-hero"><span className="pill">SIMPLE BY DESIGN</span><h2>Shop anywhere.<br/><span>Compare here.</span></h2><p>Universal My Cart is designed to sit above your favourite shopping apps—not replace them.</p></div>
    <div className="steps">
      <Step n="01" icon="↗" title="Share a product link" text="Copy any product URL and paste it into Universal My Cart. The item is added instantly." />
      <Step n="02" icon="⇄" title="Auto-sync your cart" text="With the optional browser extension or supported integrations, Add to Cart events can be mirrored automatically." />
      <Step n="03" icon="₹" title="Compare & save" text="Universal My Cart groups matching products and highlights the lowest available price." />
    </div>
    <div className="future"><div>⚡</div><div><strong>Future-ready integrations</strong><p>Automatic add-to-cart requires a browser extension, deep-link integration, or official APIs from each marketplace. The demo includes the user experience for this flow.</p></div></div>
  </section>;
}

function Step({n,icon,title,text}) {
  return <div className="step"><small>{n}</small><div className="step-icon">{icon}</div><h3>{title}</h3><p>{text}</p></div>;
}

createRoot(document.getElementById("root")).render(<App />);
