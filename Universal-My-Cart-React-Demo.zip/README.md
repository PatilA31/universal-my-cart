# Universal My Cart — React Demo

## Run locally
1. Install Node.js 20+.
2. Open this folder in a terminal.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the URL shown by Vite.

## Demo credentials
The login is intentionally mocked. Any email/password works.

## Included
- Login / signup UI
- Universal dashboard
- Products aggregated from Amazon, Flipkart, Myntra and Meesho
- Paste-link import simulation
- Lowest-price comparison
- Savings calculation
- Cart search
- Simulated Buy action
- Responsive mobile/tablet layout
- Explanation of automatic cart-sync architecture

## Important production note
The UI can demonstrate automatic cart synchronization, but a web page cannot silently read another marketplace's private cart. Production automatic sync needs one of:
- official marketplace APIs / partner integrations,
- a browser extension that observes supported shopping pages,
- deep-link/share flows,
- or user-authorized account connections.

The demo therefore models the user experience while keeping the integration boundary explicit.
